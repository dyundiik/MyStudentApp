package com.example.studentportal

data class TaskItem(
    val id: String = "",
    val title: String = "",
    val deadline: Long = 0L,
    val note: String = "",
    val done: Boolean = false
)
