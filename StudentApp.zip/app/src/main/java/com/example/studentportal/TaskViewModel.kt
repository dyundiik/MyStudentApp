package com.example.studentportal

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn

class TaskViewModel : ViewModel() {
    private val repo = TaskRepository()

    val tasks = repo.observeTasks()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun add(task: TaskItem) = repo.addTask(task)
    fun update(task: TaskItem) = repo.updateTask(task)
    fun delete(id: String) = repo.deleteTask(id)
}
