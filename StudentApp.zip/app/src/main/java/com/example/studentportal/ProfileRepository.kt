package com.example.studentportal

import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.tasks.await

class ProfileRepository {
    private val auth = FirebaseAuth.getInstance()
    private val db = FirebaseFirestore.getInstance()

    fun currentUser() = auth.currentUser

    suspend fun register(email: String, password: String) {
        auth.createUserWithEmailAndPassword(email, password).await()
    }

    suspend fun login(email: String, password: String) {
        auth.signInWithEmailAndPassword(email, password).await()
    }

    fun logout() = auth.signOut()

    suspend fun createDefaultProfileIfMissing(uid: String, email: String?) {
        val ref = db.collection("students").document(uid)
        if (ref.get().await().exists()) return

        ref.set(
            mapOf(
                "fullName" to "Павленко Майя Юріївна",
                "group" to "ІТШІ-23-3",
                "specialty" to "Комп'ютерні науки",
                "email" to (email ?: ""),
                "studentCardNumber" to "ХА14310171",
                "about" to "Студентка спеціальності «Комп'ютерні науки». Вивчаю Android-розробку та Kotlin.",
                "photoUrl" to ""
            )
        ).await()
    }

    suspend fun loadProfile(uid: String): StudentProfile? {
        val doc = db.collection("students").document(uid).get().await()
        if (!doc.exists()) return null

        return StudentProfile(
            uid = uid,
            fullName = doc.getString("fullName").orEmpty(),
            group = doc.getString("group").orEmpty(),
            specialty = doc.getString("specialty").orEmpty(),
            email = doc.getString("email").orEmpty(),
            studentCardNumber = doc.getString("studentCardNumber").orEmpty(),
            about = doc.getString("about").orEmpty(),
            photoUrl = doc.getString("photoUrl").orEmpty()
        )
    }
}
