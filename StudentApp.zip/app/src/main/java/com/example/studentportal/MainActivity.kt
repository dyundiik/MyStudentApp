package com.example.studentportal

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    val navController = rememberNavController()

                    NavHost(navController = navController, startDestination = "home") {
                        composable("home") {
                            HomeScreen(
                                onOpenTasks = { navController.navigate("tasks") },
                                onOpenProfile = { navController.navigate("profile") },
                                onOpenHealth = { navController.navigate("health") }
                            )
                        }
                        composable("tasks") {
                            TasksScreen(onBack = { navController.popBackStack() })
                        }
                        composable("profile") {
                            ProfileScreen(onBack = { navController.popBackStack() })
                        }
                        composable("health") {
                            HealthScreen(onBack = { navController.popBackStack() })
                        }
                    }
                }
            }
        }
    }
}
