package com.example.studentportal

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

data class ProfileState(
    val loading: Boolean = false,
    val authorized: Boolean = false,
    val profile: StudentProfile? = null,
    val error: String? = null
)

class ProfileViewModel : ViewModel() {
    private val repo = ProfileRepository()

    private val _state = MutableStateFlow(ProfileState())
    val state: StateFlow<ProfileState> = _state

    fun load() {
        val user = repo.currentUser()
        if (user == null) {
            _state.value = ProfileState(authorized = false)
            return
        }

        viewModelScope.launch {
            _state.value = ProfileState(loading = true, authorized = true)
            try {
                repo.createDefaultProfileIfMissing(user.uid, user.email)
                val profile = repo.loadProfile(user.uid)
                _state.value = ProfileState(loading = false, authorized = true, profile = profile)
            } catch (e: Exception) {
                _state.value = ProfileState(loading = false, authorized = true, error = e.message)
            }
        }
    }

    fun login(email: String, pass: String) {
        viewModelScope.launch {
            try {
                _state.value = _state.value.copy(loading = true, error = null)
                repo.login(email, pass)
                load()
            } catch (e: Exception) {
                _state.value = _state.value.copy(loading = false, error = e.message)
            }
        }
    }

    fun register(email: String, pass: String) {
        viewModelScope.launch {
            try {
                _state.value = _state.value.copy(loading = true, error = null)
                repo.register(email, pass)
                load()
            } catch (e: Exception) {
                _state.value = _state.value.copy(loading = false, error = e.message)
            }
        }
    }

    fun logout() {
        repo.logout()
        _state.value = ProfileState(authorized = false)
    }
}
