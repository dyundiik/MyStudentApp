package com.example.studentportal

import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.callbackFlow

class TaskRepository {
    private val auth = FirebaseAuth.getInstance()
    private val db = FirebaseFirestore.getInstance()

    private fun tasksRef(uid: String) =
        db.collection("tasks").document(uid).collection("items")

    fun observeTasks() = callbackFlow<List<TaskItem>> {
        val user = auth.currentUser
        if (user == null) {
            trySend(emptyList())
            close()
            return@callbackFlow
        }

        val listener = tasksRef(user.uid).addSnapshotListener { snapshot, _ ->
            val tasks = snapshot?.documents?.mapNotNull { doc ->
                doc.toObject(TaskItem::class.java)?.copy(id = doc.id)
            } ?: emptyList()

            trySend(tasks)
        }

        awaitClose { listener.remove() }
    }

    fun addTask(task: TaskItem) {
        val user = auth.currentUser ?: return
        tasksRef(user.uid).document(task.id).set(task)
    }

    fun updateTask(task: TaskItem) {
        val user = auth.currentUser ?: return
        tasksRef(user.uid).document(task.id).set(task)
    }

    fun deleteTask(id: String) {
        val user = auth.currentUser ?: return
        tasksRef(user.uid).document(id).delete()
    }
}
