package com.example.studentportal

data class StudentProfile(
    val uid: String = "",
    val fullName: String = "",
    val group: String = "",
    val specialty: String = "",
    val email: String = "",
    val studentCardNumber: String = "",
    val about: String = "",
    val photoUrl: String = ""
)
