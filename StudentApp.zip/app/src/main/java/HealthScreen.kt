package com.example.studentportal

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun HealthScreen(onBack: () -> Unit) {
    val habits = listOf("Випити воду", "Перерва 5 хв", "Вправа для очей", "Розминка")
    val checked = remember { mutableStateListOf(false, false, false, false) }

    Column(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Health & Focus", style = MaterialTheme.typography.headlineSmall)

        Card {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Поради", style = MaterialTheme.typography.titleMedium)
                Text("• Правило 20-20-20 для очей")
                Text("• Робити перерви щогодини")
                Text("• Пити воду протягом дня")
            }
        }

        Card {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Habit tracker (сьогодні)", style = MaterialTheme.typography.titleMedium)

                habits.forEachIndexed { i, name ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(
                            checked = checked[i],
                            onCheckedChange = { checked[i] = it }
                        )
                        Spacer(Modifier.width(8.dp))
                        Text(name)
                    }
                }
            }
        }

        Button(onClick = onBack) { Text("Back") }
    }
}
