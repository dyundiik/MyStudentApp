package com.example.studentportal

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.time.format.DateTimeParseException
import java.util.UUID

private val inputFormatter: DateTimeFormatter = DateTimeFormatter.ISO_LOCAL_DATE
private val zoneId: ZoneId = ZoneId.systemDefault()

private fun localDateToMillis(date: LocalDate): Long {
    return date.atStartOfDay(zoneId).toInstant().toEpochMilli()
}

private fun millisToLocalDate(millis: Long): LocalDate {
    return Instant.ofEpochMilli(millis).atZone(zoneId).toLocalDate()
}

@Composable
fun TasksScreen(onBack: () -> Unit) {
    val vm: TaskViewModel = viewModel()
    val tasksFromDb by vm.tasks.collectAsState()
    val user = ProfileRepository().currentUser()
    if (user == null) {
        Column(
            modifier = Modifier.fillMaxSize().padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text("Tasks / Deadlines", style = MaterialTheme.typography.headlineSmall)
            Text("Щоб переглядати завдання, потрібно увійти (Auth).")
            Button(onClick = onBack) { Text("Back") }
        }
        return
    }

    var title by remember { mutableStateOf("") }
    var deadlineText by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    var errorText by remember { mutableStateOf<String?>(null) }
    var editingTaskId by remember { mutableStateOf<String?>(null) }

    val sortedTasks by remember(tasksFromDb) {
        derivedStateOf {
            tasksFromDb.sortedWith(
                compareBy<TaskItem> { it.done }.thenBy { it.deadline }
            )
        }
    }

    Column(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Tasks / Deadlines", style = MaterialTheme.typography.headlineSmall)

        Card {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    if (editingTaskId == null) "Додати завдання" else "Редагувати завдання",
                    style = MaterialTheme.typography.titleMedium
                )

                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Назва завдання") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = deadlineText,
                    onValueChange = { deadlineText = it },
                    label = { Text("Дедлайн (YYYY-MM-DD)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = note,
                    onValueChange = { note = it },
                    label = { Text("Коментар / опис") },
                    modifier = Modifier.fillMaxWidth(),
                    minLines = 2
                )

                errorText?.let { Text(it, color = MaterialTheme.colorScheme.error) }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Button(
                        onClick = {
                            val t = title.trim()
                            val n = note.trim()

                            if (t.isEmpty()) {
                                errorText = "Введи назву завдання."
                                return@Button
                            }

                            val parsedMillis = try {
                                val d = LocalDate.parse(deadlineText.trim(), inputFormatter)
                                localDateToMillis(d)
                            } catch (e: DateTimeParseException) {
                                errorText = "Неправильна дата. Формат: YYYY-MM-DD (наприклад 2025-12-20)."
                                return@Button
                            }

                            if (editingTaskId == null) {
                                val newTask = TaskItem(
                                    id = UUID.randomUUID().toString(),
                                    title = t,
                                    deadline = parsedMillis,
                                    note = n,
                                    done = false
                                )
                                vm.add(newTask)
                            } else {
                                val old = tasksFromDb.firstOrNull { it.id == editingTaskId }
                                if (old != null) {
                                    vm.update(
                                        old.copy(
                                            title = t,
                                            deadline = parsedMillis,
                                            note = n
                                        )
                                    )
                                }
                                editingTaskId = null
                            }

                            title = ""
                            deadlineText = ""
                            note = ""
                            errorText = null
                        },
                        modifier = Modifier.weight(1f)
                    ) {
                        Text(if (editingTaskId == null) "Add" else "Save")
                    }

                    if (editingTaskId != null) {
                        OutlinedButton(
                            onClick = {
                                editingTaskId = null
                                title = ""
                                deadlineText = ""
                                note = ""
                                errorText = null
                            },
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("Cancel")
                        }
                    }
                }
            }
        }

        Card(modifier = Modifier.fillMaxSize()) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text("Список завдань", style = MaterialTheme.typography.titleMedium)

                if (sortedTasks.isEmpty()) {
                    Text("Поки що немає завдань. Додай перше у формі вище 🙂")
                } else {
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        items(sortedTasks, key = { it.id }) { task ->
                            val deadlineDate = millisToLocalDate(task.deadline)
                            val isOverdue = !task.done && deadlineDate.isBefore(LocalDate.now())

                            TaskRow(
                                task = task,
                                deadlineDateText = deadlineDate.toString(),
                                isOverdue = isOverdue,
                                onToggleDone = { checked ->
                                    vm.update(task.copy(done = checked))
                                },
                                onDelete = {
                                    vm.delete(task.id)
                                    if (editingTaskId == task.id) {
                                        editingTaskId = null
                                        title = ""
                                        deadlineText = ""
                                        note = ""
                                        errorText = null
                                    }
                                },
                                onEdit = {
                                    title = task.title
                                    deadlineText = deadlineDate.toString()
                                    note = task.note
                                    editingTaskId = task.id
                                    errorText = null
                                }
                            )
                        }
                    }
                }
            }
        }

        Button(onClick = onBack) { Text("Back") }
    }
}

@Composable
private fun TaskRow(
    task: TaskItem,
    deadlineDateText: String,
    isOverdue: Boolean,
    onToggleDone: (Boolean) -> Unit,
    onDelete: () -> Unit,
    onEdit: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth().clickable { onEdit() }
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Checkbox(
                    checked = task.done,
                    onCheckedChange = onToggleDone
                )

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = task.title,
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(
                        text = "Дедлайн: $deadlineDateText",
                        style = MaterialTheme.typography.bodyMedium,
                        color = when {
                            task.done -> MaterialTheme.colorScheme.onSurfaceVariant
                            isOverdue -> MaterialTheme.colorScheme.error
                            else -> MaterialTheme.colorScheme.onSurfaceVariant
                        }
                    )
                }

                TextButton(onClick = onDelete) { Text("Delete") }
            }

            if (task.note.isNotBlank()) {
                Text(task.note, style = MaterialTheme.typography.bodyMedium)
            }

            if (isOverdue) {
                Text("⚠ Прострочено", color = MaterialTheme.colorScheme.error)
            }
        }
    }
}
