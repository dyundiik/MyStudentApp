package com.example.studentportal

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun HomeScreen(
    onOpenTasks: () -> Unit,
    onOpenProfile: () -> Unit,
    onOpenHealth: () -> Unit
) {
    Column(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp, Alignment.CenterVertically),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("Student Mini-Portal", style = MaterialTheme.typography.headlineSmall)

        Card {
            Text(
                modifier = Modifier.padding(16.dp),
                text = "Головне меню: дедлайни, профіль студента та здоров’я."
            )
        }

        Button(onClick = onOpenTasks) { Text("Tasks / Deadlines") }
        Button(onClick = onOpenProfile) { Text("Student ID / Profile") }
        Button(onClick = onOpenHealth) { Text("Health & Focus") }
    }
}
