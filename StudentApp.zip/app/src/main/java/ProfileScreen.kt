package com.example.studentportal

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel

@Composable
fun ProfileScreen(onBack: () -> Unit) {
    val vm: ProfileViewModel = viewModel()
    val state by vm.state.collectAsState()

    LaunchedEffect(Unit) { vm.load() }

    Column(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Student ID / Profile", style = MaterialTheme.typography.headlineSmall)

        if (state.loading) {
            Card {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    CircularProgressIndicator()
                    Spacer(Modifier.width(12.dp))
                    Text("Завантаження...")
                }
            }
        }

        state.error?.let {
            Text("Помилка: $it", color = MaterialTheme.colorScheme.error)
        }

        if (!state.authorized) {
            AuthBlock(
                onLogin = { e, p -> vm.login(e, p) },
                onRegister = { e, p -> vm.register(e, p) }
            )
        } else {
            val p = state.profile

            Card {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.student_photo),
                        contentDescription = "Student photo",
                        modifier = Modifier.size(120.dp).clip(CircleShape)
                    )

                    Text("ПІБ: ${p?.fullName.orEmpty()}", style = MaterialTheme.typography.titleMedium)
                    Text("Група: ${p?.group.orEmpty()}")
                    Text("Спеціальність: ${p?.specialty.orEmpty()}")
                    Text("Email: ${p?.email.orEmpty()}")
                    Text("№ студентського квитка: ${p?.studentCardNumber.orEmpty()}")
                    Text(p?.about.orEmpty())
                }
            }

            Button(onClick = { vm.logout() }) { Text("Logout") }
        }

        Button(onClick = onBack) { Text("Back") }
    }
}

@Composable
private fun AuthBlock(
    onLogin: (String, String) -> Unit,
    onRegister: (String, String) -> Unit
) {
    var email by remember { mutableStateOf("") }
    var pass by remember { mutableStateOf("") }

    Card {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text("Вхід / Реєстрація", style = MaterialTheme.typography.titleMedium)

            OutlinedTextField(
                value = email,
                onValueChange = { email = it },
                label = { Text("Email") },
                singleLine = true
            )

            OutlinedTextField(
                value = pass,
                onValueChange = { pass = it },
                label = { Text("Password (мін 6 символів)") },
                singleLine = true
            )

            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(onClick = { onLogin(email.trim(), pass) }) { Text("Login") }
                Button(onClick = { onRegister(email.trim(), pass) }) { Text("Register") }
            }
        }
    }
}
